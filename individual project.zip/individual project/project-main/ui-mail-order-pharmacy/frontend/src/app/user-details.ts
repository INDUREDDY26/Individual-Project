export interface UserDetails {
    userid: string
    uname: string;
    upassword :string;
    authToken :string;
}