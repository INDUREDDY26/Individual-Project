package com.cts.exception;

@SuppressWarnings("serial")
public class SubscriptionIDNotFoundException extends Exception{
	
	public SubscriptionIDNotFoundException(String msg) {
		super(msg);
	}

}
