package com.cts.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.RefillOrder;

public interface RefillOrderRepository extends JpaRepository<RefillOrder, Long>{

}
