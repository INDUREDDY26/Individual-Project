insert into user (userid,upassword,uname) values ('admin','admin','admin');

insert into user (userid,upassword,uname) values ('admin1','admin1','admin1');
insert into user (userid,upassword,uname) values ('admin2','admin2','admin2');
insert into user (userid,upassword,uname) values ('admin3','admin3','admin3');
insert into user (userid,upassword,uname) values ('user1','user1','user1');
insert into user (userid,upassword,uname) values ('user2','user2','user2');
insert into user (userid,upassword,uname) values ('user3','user3','user3');
insert into user (userid,upassword,uname) values ('user4','user4','user4');