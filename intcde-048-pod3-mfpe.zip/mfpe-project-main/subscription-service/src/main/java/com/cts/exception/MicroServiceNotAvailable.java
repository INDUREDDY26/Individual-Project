package com.cts.exception;


public class MicroServiceNotAvailable extends Exception {

	
	
	public  MicroServiceNotAvailable(String msg) {
		
		super(msg);

	}
	
}
