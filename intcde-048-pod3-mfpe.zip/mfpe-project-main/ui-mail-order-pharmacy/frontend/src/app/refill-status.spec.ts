import { RefillStatus } from './refill-status';

describe('RefillStatus', () => {
  it('should create an instance', () => {
    expect(new RefillStatus()).toBeTruthy();
  });
});
